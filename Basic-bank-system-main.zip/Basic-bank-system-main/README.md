# Basic-bank-system
Task-1

Spark Foundation Web Development and Designing Internship Project: To create a simple dynamic Basic banking system website. It is used to transfer the money between multilpe users and also record the banking transactions history.

Flow : Home Page > View all customers > Select and View one customer > Transfer Money > Select customer to transfer to > View all Customers.
